import time
import io
import os
import pyautogui
import json 
import socketio
import base64

# load the timeout from a config file clientConfig.json
with open('clientConfig.json') as f:
    config = json.load(f)
    timeout = config['timeout']
    screenshot_folder = config['screenshot_folder']
    screenshot_file = config['screenshot_file']
    server = config['server']['host']
    port = config['server']['port']

print()
print()
print("###########################################")
print("Client started successfully")
print("Timeout: " + str(timeout) + " seconds")
print("Screenshot folder: " + screenshot_folder)
print("Screenshot file: " + screenshot_file)
print("Server: " + server + ":" + str(port))
print("===========================================")
print()
print()
# if the screenshot_folder folder doesn't exist, create it
if not os.path.exists(screenshot_folder):
    os.mkdir(screenshot_folder)

if os.path.exists(os.path.join(screenshot_folder,screenshot_file)):
    os.remove(os.path.join(screenshot_folder,screenshot_file))

print("Connecting to Socket Server")

# Connect to the Flask-SocketIO server
sio = socketio.Client()
sio.connect(f"http://{server}:{port}")
sio.emit('client-connect', {'username': os.getlogin()})

@sio.event
def connect():
    print("Connected to Socket Server")
    sio.emit('client-connect', {'username': os.getlogin()})

@sio.event
def disconnect():
    print("Disconnected from Socket Server")

@sio.event
def update_config(data):
    print("Updating config to ",data)
    global timeout
    if data['timeout'] != timeout:
        timeout = data['timeout']
        print("Timeout updated to:", timeout)
        # write the updated timeout to the config file
        with open('clientConfig.json', 'w') as f:
            config['timeout'] = timeout
            json.dump(config, f, indent=4)


loop = 0

while True:
    loop+=1
    # get the pc username
    username = os.getlogin()
    ctime = time.strftime('%Y-%m-%d_%H-%M-%S')
    try:
        # take a screenshot
        screenshot = pyautogui.screenshot()
    except:
        time.sleep(timeout)
        continue
    screenshot.thumbnail((screenshot.size[0] / 2, screenshot.size[1] / 2))

    # save the screenshot in the screenshot_folder folder
    screenshot.save(os.path.join(screenshot_folder,screenshot_file))

    # convert the screenshot in valid format to send over websockets
    with open(os.path.join(screenshot_folder,screenshot_file), 'rb') as f:
        img_data = base64.b64encode(f.read()).decode('utf-8')

    # create a dictionary with username, time and screenshot
    data = {'username': username, 'time': ctime,'screenshot': img_data}
    # check if socket is connected
    if sio.connected:
        sio.emit('screenshot-updated', data)
        print("Screenshot sent successfully")
        os.remove(os.path.join(screenshot_folder,screenshot_file))
        time.sleep(timeout)
    else:
        print("Socket not connected")
        time.sleep(timeout)